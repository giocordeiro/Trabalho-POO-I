import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class GestaoFinanceira {

    private ArrayList<RelatorioMensal> relatoriosMensais;
    public static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public GestaoFinanceira() {
        this.relatoriosMensais = new ArrayList<>();
    }

    public void adicionarGasto(Gasto gasto) {
        LocalDate dataGasto = LocalDate.parse(gasto.getData(), FORMATO_DATA);
        int mes = dataGasto.getMonthValue();
        int ano = dataGasto.getYear();
        RelatorioMensal relatorioMensal = buscarRelatorioMensal(mes, ano);
        if (relatorioMensal == null) {
            relatorioMensal = new RelatorioMensal(mes, ano);
            relatoriosMensais.add(relatorioMensal);
        }
        relatorioMensal.adicionarGasto(gasto);
    }

    public void adicionarGanho(Ganho ganho) {
        LocalDate dataGanho = LocalDate.parse(ganho.getData(), FORMATO_DATA);
        int mes = dataGanho.getMonthValue();
        int ano = dataGanho.getYear();
        RelatorioMensal relatorioMensal = buscarRelatorioMensal(mes, ano);
        if (relatorioMensal == null) {
            relatorioMensal = new RelatorioMensal(mes, ano);
            relatoriosMensais.add(relatorioMensal);
        }
        relatorioMensal.adicionarGanho(ganho);
    }

    public RelatorioMensal buscarRelatorioMensal(int mes, int ano) {
        for (RelatorioMensal relatorioMensal : relatoriosMensais) {
            if (relatorioMensal.getMes() == mes && relatorioMensal.getAno() == ano) {
                return relatorioMensal;
            }
        }
        return null;
    }

    public ArrayList<RelatorioMensal> getRelatoriosMensais() {
        return relatoriosMensais;
    }

}