import java.util.ArrayList;

public class RelatorioMensal {
    private int mes;
    private int ano;
    private ArrayList<Gasto> gastos;
    private ArrayList<Ganho> ganhos;

    public RelatorioMensal(int mes, int ano) {
        this.mes = mes;
        this.ano = ano;
        this.gastos = new ArrayList<>();
        this.ganhos = new ArrayList<>();
    }

    public void adicionarGasto(Gasto gasto) {
        gastos.add(gasto);
    }

    public void adicionarGanho(Ganho ganho) {
        ganhos.add(ganho);
    }

    public double getGastoTotal() {
        double total = 0;
        for (Gasto gasto : gastos) {
            total += gasto.getValor();
        }
        return total;
    }

    public double getGanhoTotal() {
        double total = 0;
        for (Ganho ganho : ganhos) {
            total += ganho.getValor();
        }
        return total;
    }

    public double getSaldo() {
        return getGanhoTotal() - getGastoTotal();
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
}