import java.time.LocalDate;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        GestaoFinanceira gf = new GestaoFinanceira();

        int opcao;
        do {
            System.out.println("\nGestão Financeira");
            System.out.println("-----------------------");
            System.out.println("1 - Adicionar Gasto");
            System.out.println("2 - Adicionar Ganho");
            System.out.println("3 - Relatório de Gastos");
            System.out.println("4 - Relatório de Ganhos");
            System.out.println("5 - Relatório Mensal");
            System.out.println("6 - Sair\n");

            System.out.print("Selecione uma opção: ");
            opcao = input.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("\nAdicionar Gasto");
                    System.out.println("-----------------------");
                    System.out.println("1 - Habitação");
                    System.out.println("2 - Entretenimento");
                    System.out.println("3 - Alimentação");
                    System.out.println("4 - Transporte");
                    System.out.println("X - SEU GASTO");
                    System.out.println("99 - Voltar\n");

                    System.out.print("Selecione o tipo de gasto: ");
                    int tipoGasto = input.nextInt();

                    if (tipoGasto == 99) break;

                    System.out.println("\nAdicionar Gasto");
                    System.out.println("-----------------------");
                    System.out.print("Informe a data (dd/mm/aaaa): ");
                    String dataGastoStr = input.next();
                    LocalDate dataGasto = LocalDate.parse(dataGastoStr, GestaoFinanceira.FORMATO_DATA);

                    System.out.print("Informe o valor: R$ ");
                    double valorGasto = input.nextDouble();

                    System.out.println("\n1 - Cheque");
                    System.out.println("2 - Pix");
                    System.out.println("3 - Débito");
                    System.out.print("Selecione a forma de pagamento: ");
                    int formaPagamentoGasto = input.nextInt();

                    switch (tipoGasto) {
                        case 1:
                            gf.adicionarGasto(new Gasto(GastoTipo.HABITACAO, dataGasto, valorGasto, formaPagamentoGasto));
                            break;
                        case 2:
                            gf.adicionarGasto(new Gasto(GastoTipo.ENTRETENIMENTO, dataGasto, valorGasto, formaPagamentoGasto));
                            break;
                        case 3:
                            gf.adicionarGasto(new Gasto(GastoTipo.ALIMENTACAO, dataGasto, valorGasto, formaPagamentoGasto));
                            break;
                        case 4:
                            gf.adicionarGasto(new Gasto(GastoTipo.TRANSPORTE, dataGasto, valorGasto, formaPagamentoGasto));
                            break;
                        default:
                            System.out.print("Informe o tipo do gasto: ");
                            String tipoGastoStr = input.next();
                            gf.adicionarGasto(new Gasto(tipoGastoStr, dataGasto, valorGasto, formaPagamentoGasto));
                            break;
                    }

                    System.out.println("\nGasto adicionado com sucesso!");
                    break;

                case 2:
                    System.out.println("\nAdicionar Ganho");
                    System.out.println("-----------------------");
                    System.out.println("1 - Salário");
                    System.out.println("2 - Freelancer");
                    System.out.println("3 - Dividendos");
                    System.out.println("X - SEU GANHO");
                    System.out.println("99 - Voltar\n");

                    System.out.print("Selecione o tipo de ganho: ");
                    int tipoGanho = input.nextInt();

                    if (tipoGanho == 99) break;

                    System.out.println("\nAdicionar Ganho");
                    System.out.println("-----------------------");
                    System.out.print("Informe a data (dd/mm/aaaa): ");
                    String dataGanhoStr = input.next();
                    LocalDate dataGanho = LocalDate.parse(dataGanhoStr, GestaoFinanceira.FORMATO_DATA);

                    System.out.print("Informe o valor: R$ ");
                    double valorGanho = input.nextDouble();

                    switch (tipoGanho) {
                        case 1:
                            gf.adicionarGanho(new Ganho(GanhoTipo.SALARIO, dataGanho, valorGanho));
                            break;
                        case 2:
                            gf.adicionarGanho(new Ganho(GanhoTipo.FREELANCER, dataGanho, valorGanho));
                            break;
                        case 3:
                            gf.adicionarGanho(new Ganho(GanhoTipo.DIVIDENDOS, dataGanho, valorGanho));
                            break;
                        default:
                            System.out.print("Informe o tipo do ganho: ");
                            String tipoGanhoStr = input.next();
                            gf.adicionarGanho(new Ganho(tipoGanhoStr, dataGanho, valorGanho));
                            break;
                    }

                    System.out.println("\nGanho adicionado com sucesso!");
                    break;

                case 3:
                    System.out.println("\nRelatório de Gastos");
                    System.out.println("-----------------------");
                    System.out.println(gf.relatorioGastos());
                    break;

                case 4:
                    System.out.println("\nRelatório de Ganhos");
                    System.out.println("-----------------------");
                    System.out.println(gf.relatorioGanhos());
                    break;

                case 5:
                    System.out.println("\nRelatório Mensal");
                    System.out.println("-----------------------");
                    System.out.print("Informe o mês (mm/aaaa): ");
                    String mesAno = input.next();
                    System.out.println(gf.relatorioMensal(mesAno));
                    break;

                case 6:
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opção inválida!");
                    break;
            }

        } while (opcao != 6);

        input.close();
    }